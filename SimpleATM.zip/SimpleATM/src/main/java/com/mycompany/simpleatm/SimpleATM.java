/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simpleatm;
import java.util.Scanner;
/**
 *
 * @author aadjei
 */
public class SimpleATM {

    public static void main(String[] args) {
       Scanner scanner=new Scanner(System.in);
       
       Bank myBank=new Bank("Bank of Ghana");
       
       User newUser = myBank.addNewUser("Akua","Adjei","2348");
       
    Account myAccount= new Account("Checking",newUser,myBank);
    
    newUser.addAccount(myAccount);
    myBank.addAccount(myAccount);
    
    User currentUser;
    while(true){
        //stay in login prompt until successful login
        currentUser=SimpleATM.mainMenuPrompt(myBank,scanner);
        
        //stay in main menu until user quits
        SimpleATM.printUserMenu(currentUser,scanner);
        
    }
}
    public static User mainMenuPrompt(Bank myBank,Scanner scanner){
      //inits
      String userId;
      String pin;
      User authenticUser;
      //prompt user for user Id till we get the correct combo
      do{
          System.out.printf("\n\nWelcome %s\n\n",myBank.getName());
          System.out.println(" Type in you User Id: ");
         userId= scanner.nextLine(); 
         System.out.print("Type in your pin please:" );
         pin=scanner.nextLine();
       
         
         //let use object be the same as userId and pin
         
         authenticUser=myBank.userLogin(userId, pin);
         if(authenticUser==null){
            
             System.out.println("Incorrect " + "Please try again. ");
         }
         
         
      }while(authenticUser==null);
      return authenticUser;
    }
    
    public static void printUserMenu(User currentUser,Scanner scanner){
    // print a summary of the user's accounts 
        currentUser.printAccountSummary();
        
        int choice;
        
        do{
           System.out.printf("Welcome %,what would like to do today? ", currentUser.getFirstName()); 
           System.out.println("1. Show Acccount Transaction History");
           System.out.println("2. Withdraw");
           System.out.println("3 Deposit");
           System.out.println("4. Transfer");
           System.out.println("5. Quit");
           System.out.println();
           System.out.println("Select you choice please: ");
           choice=scanner.nextInt();
           
           if(choice<1||choice>5){
               
               System.out.println("Option not available"+ "Please select digits betweer 1 and 5");
           }
           
           
        }
        while(choice<1||choice>5);
    switch(choice){
        case 1:
            SimpleATM.showAccountTransactionHistory(currentUser,scanner);
            break;
            
        case 2:
            SimpleATM.withdraw(currentUser,scanner);
            break;
        case 3:
            SimpleATM.deposit(currentUser,scanner);
            break;
        case 4:
            SimpleATM.transfer(currentUser,scanner);
            break;
        case 5 :
            scanner.nextLine();
            break;
    }
    // displaybmenu again if the user doesnt want to quit
    
    if(choice!=5){
    
    SimpleATM.printUserMenu(currentUser,scanner);
    }
    
}
    public static void showAccountTransactionHistory(User currentUser,Scanner scanner){
        int theAccount;
       do{
           System.out.printf("Enter the number (1-%d) of the account" +"whose transactions that you want to see: ",
                   currentUser.numberOfAccounts());
           theAccount=scanner.nextInt()-1;
           
           if (theAccount <0 || theAccount >=currentUser.numberOfAccounts())
               System.out.println("Invalid Option. Please try again");
       } while(theAccount <0 || theAccount >=currentUser.numberOfAccounts());
       currentUser.printAccountTransactionHistory(theAccount);
    }
    
    public static void transfer(User currentUser,Scanner scanner){
        int fromAccount;
        int toAccount;
        double amount;
        double accountBalance;
        
        //transfer from
        do{
           System.out.printf("Enter the number (1 -%d) of the acccount you want to transfer from: ",currentUser.numberOfAccounts()) ;
           fromAccount = scanner.nextByte()-1;
           
           if(fromAccount < 0 || fromAccount>= currentUser.numberOfAccounts())
           {
                System.out.println("Invalid Option. Please try again");
           }}while(fromAccount <0 || fromAccount >=currentUser.numberOfAccounts());
        accountBalance=currentUser.getAccountBalance(fromAccount);
    
    
   // transfer to
    
do{
           System.out.printf("Enter the number (1 -%d) of the acccount you want to transfer from: ",currentUser.numberOfAccounts()) ;
           toAccount = scanner.nextByte()-1;
           
           if(toAccount < 0 || toAccount>= currentUser.numberOfAccounts())
           {
                System.out.println("Invalid Option. Please try again");
           }}while(toAccount <0 || toAccount >=currentUser.numberOfAccounts());
        
//amount to be transfered

do{
    System.out.printf("Enter amount of you want to transfer (max $%.02f: $", accountBalance);
    amount=scanner.nextDouble();
    if(amount<0||amount > accountBalance){
        System.out.println("Amount cannot be less than 0 or more than account balance");
        
         
    }
}while(amount<0||amount > accountBalance);
    
    //do transet
    currentUser.addAccountTransaction(fromAccount, -1*amount,String.format("Transfer to account%s",currentUser.getAccountId(toAccount)));
 currentUser.addAccountTransaction(toAccount, amount,String.format("Transfer accepepted from account%s",currentUser.getAccountId(fromAccount)));
 

    }
public static void withdraw(User currentUser,Scanner scanner ){
    int fromAccount;
       
        double amount;
        double accountBalance;
        String memo;
        //transfer from
        do{
           System.out.printf("Enter the number (1 -%d) of the acccount you want to transfer from: ",currentUser.numberOfAccounts()) ;
           fromAccount = scanner.nextByte()-1;
           
           if(fromAccount < 0 || fromAccount>= currentUser.numberOfAccounts())
           {
                System.out.println("Invalid Option. Please try again");
           }}while(fromAccount <0 || fromAccount >=currentUser.numberOfAccounts());
        accountBalance=currentUser.getAccountBalance(fromAccount);
    
    
do{
    System.out.printf("Enter amount of you want to transfer (max $%.02f: $", accountBalance);
    amount=scanner.nextDouble();
    if(amount<0||amount > accountBalance){
        System.out.println("Amount cannot be less than 0 or more than account balance");
        
         
    }
}while(amount<0||amount > accountBalance);
    scanner.nextLine();
    
    System.out.println("Enter a memo: ");
    memo=scanner.nextLine();
    //lets do the withdrawal
    currentUser.addAccountTransaction(fromAccount,-1*amount,memo);
}

public static void deposit(User currentUser,Scanner scanner){
    int toAccount;
       
        double amount;
        double accountBalance;
        String memo;
        //transfer from
        do{
           System.out.printf("Enter the number (1 -%d) of the acccount you want to deposit in: ",currentUser.numberOfAccounts()) ;
           toAccount = scanner.nextByte()-1;
           
           if(toAccount < 0 || toAccount>= currentUser.numberOfAccounts())
           {
                System.out.println("Invalid Option. Please try again");
           }}while(toAccount <0 || toAccount >=currentUser.numberOfAccounts());
        accountBalance=currentUser.getAccountBalance(toAccount);
    
    
do{
    System.out.printf("Enter amount of you want to transfer (max $%.02f: $", accountBalance);
    amount=scanner.nextDouble();
    if(amount<0){
        System.out.println("Amount cannot be less than 0 ");
        
         
    }
}while(amount<0);
    scanner.nextLine();
    
    System.out.println("Enter a memo: ");
    memo=scanner.nextLine();
    //lets do the withdrawal
    currentUser.addAccountTransaction(toAccount,amount,memo);
}
}
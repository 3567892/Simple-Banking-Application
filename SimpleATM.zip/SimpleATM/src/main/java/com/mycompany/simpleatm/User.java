/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.simpleatm;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aadjei
 */
public class User {
    private String firstName;
    private String lastName;
    private String userId;
    private byte pinHash[];
    private ArrayList<Account> accounts;
    
    
    
    /*
    * firstName-user's firstName
    lastName=user's lastName
    pin=user's account pin number
    theBank= the bank object that the user saves at
    */
    
    public User(String firstName, String lastName,String pin, Bank theBank){
        this.firstName=firstName;
        this.lastName=lastName;
        
        try {
            //store pin hash instead of original password

            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            this.pinHash = messageDigest.digest(pin.getBytes());
        } catch (NoSuchAlgorithmException ex) {
            System.err.println("Error,caught NoSuchAlgorithmException");
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(1);
        }
        
        
        //get a new ,user Id for use
        this.userId=theBank.getNewUserId();
        
        //accounts lists
        this.accounts=new ArrayList<Account>();
        
      //  print log
        System.out.printf("New User %s,%s with ID %s created.\n", this.firstName,this.lastName,this.userId);
        
    }
    // adds an account to the owner's list of accounts
    public void addAccount(Account anAccount){
        this.accounts.add(anAccount);
    }
    
    
    public String getNewUserId(){
        return this.userId;
    }
    
    public boolean checkPin(String aPin){
        try {
            MessageDigest messageDigest= MessageDigest.getInstance("MD5");
            return MessageDigest.isEqual(messageDigest.digest(aPin.getBytes()),
                    this.pinHash);
            
        } catch (NoSuchAlgorithmException ex) {
            System.err.println("Error,caught NoSuchAlgorithmException");
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(1);
        }
        System.out.println(aPin);
             
        return false;     
    }
    
    public String getFirstName(){
        return this.firstName;
    }
   
    
   public void printAccountSummary(){
       System.out.printf("\n\n %s'sm account info:  ",this.firstName);
       for(int i=0;i<this.accounts.size();i++){
          System.out.printf("%d) %s ",i+1, this.accounts.get(i).getAccountSummaryLine()); 
       }
       System.out.println();
   }
   
   public int numberOfAccounts(){
       return this.accounts.size();
   }
   
   public void printAccountTransactionHistory(int accountIndex){
       this.accounts.get(accountIndex).printTransactionHistory();
       
   }
   
   public double getAccountBalance(int accountIndex){
       return this.accounts.get(accountIndex).getBalance();
   }
   
   public String getAccountId(int accountIndex){
       return this.accounts.get(accountIndex).getNewAccountId();
   }
   
   public void addAccountTransaction(int AccountIndex,double amount,String memo ){
       this.accounts.get(AccountIndex).addTransaction(amount,memo);
       
   }
   
}
    


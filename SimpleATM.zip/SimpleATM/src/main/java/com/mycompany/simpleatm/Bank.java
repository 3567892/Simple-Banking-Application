/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.simpleatm;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author aadjei
 */
public class Bank {
  private String name;
  private ArrayList<User> users;
  private ArrayList<Account> accounts;

public Bank(String name){
    this.name=name;
    this.accounts=new ArrayList<Account>();
    this.users=new ArrayList<User>();
}
  
  
  public String getNewUserId(){
     int length= 6;//length of the id
     String userId;
     Random randomNumber = new Random();
     boolean nonUnique;
     
     
     //loop continues till a new Unique id is generated
     do{
         /*generates the number*/
         userId=" ";
         for(int i =0; i <length;i++){
             userId +=((Integer)randomNumber.nextInt(10)).toString();
         }
         nonUnique=false;
         for(User u:this.users){
             if(userId.compareTo(u.getNewUserId())==0){
                 nonUnique=true;
                 break;
             }
         }
     }while(nonUnique);
     
     return userId;
      
  }
  
  
  public String getNewAccountId(){
    int length=12;
    String accountId;
    Random randomNumber= new Random();
    boolean nonUnique;
    
    do{
        accountId="";
        for(int i =0;i<length;i++){
            accountId += ((Integer)randomNumber.nextInt(10)).toString();
        }
        //check to make sure id is unique
        nonUnique=false;
        for(Account acc : this.accounts){
            if(accountId.compareTo(acc.getNewAccountId())==0){
                nonUnique=true;
                break;
            }
            
        }
        
    } while (nonUnique);
    
    return accountId;
  }
  
 
  
    public void addAccount(Account anAccount){
      this.accounts.add(anAccount);
  }
    
    public User addNewUser(String firstName,String lastName,String pin){
        //create a new User object
       User newUser = new User(firstName,lastName,pin,this);
       this.users.add(newUser);
       //create a savings account
      Account newAccount= new Account("Savings",newUser,this);
              
        //updates or add this new account to the  accountOwner and bank lists
      newUser.addAccount(newAccount);
     this.addAccount(newAccount);
      return newUser;
    }
    
    public User userLogin(String userId,String pin){
        System.out.println(userId+pin);
        for (User u:this.users){
            if(u.getNewUserId().compareTo(userId)==0 ){
                if( u.checkPin(pin) ){
                return u;
                
            }else{
        
        return null;
    }
            }
        }
        return null;
    }
    
    public String getName(){
        return this.name;
    }
}

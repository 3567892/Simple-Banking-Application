/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.simpleatm;


import java.util.ArrayList;
/**
 *
 * @author aadjei
 */
public class Account {
    private String name;
    private String accountId;
    private User accountOwner;
    private ArrayList<Transaction> transactions;
    
    /*
    name=name of account(ie account type)
    accountOwner=the Owner of the account(ie the User)
    theBank=the Bank that the account is being created in
    */
    public Account(String  name, User accountOwner,Bank theBank){
        //set the account name and holder
        this.name=name;
        this.accountOwner=accountOwner;
        this.accountId= theBank.getNewAccountId();
        this.transactions=new ArrayList<>();
        

    }
    
    public String getNewAccountId(){
        return this.accountId;
    }
    
  public String getAccountSummaryLine(){
      //grab account balance
      double balance =this.getBalance();
      
      
      
      // format  the summary line, considering if the blance is negative
      if(balance>=0){
          return String.format("%s : $%.02f : %s ", this.accountId,balance,this.name);
          
      }else{
          return String.format("%s : $(%.02f) : %s ", this.accountId,balance,this.name);
      }
      
  }
  
  public double getBalance(){
      double balance=0;
      for(Transaction allTransactions : this.transactions){
        balance   += allTransactions.getAmount();
      }
      return balance;
  }
  //prints the transaction history
  public void printTransactionHistory(){
    System.out.printf("\nTransaction History for a account %s \n", this.accountId);
    for (int i = this.transactions.size()-1;i>=0;i--){
        System.out.printf(this.transactions.get(i).getSummaryLine());
    }
     System.out.println();
} 
   
  public void addTransaction (double amount,String memo){
      //create a new transaction object to be addeed
      
      Transaction newTransaction = new Transaction(amount,memo,this);
      this.transactions.add(newTransaction);
      
  }
    
}

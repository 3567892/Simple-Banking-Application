/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.simpleatm;

import java.util.Date;

/**
 *
 * @author aadjei
 */
public class Transaction {
    
    private double amount;
    private Date timeStamp;
    private String memo;
  //the account which the transaction happened in
   private Account whichAccount;
    
   /*
   Create a new transaction
   amount=the amount transacted
   
   */
   public Transaction(double amount , Account whichAccount){
       this.amount=amount;
       this.whichAccount=whichAccount;
       this.timeStamp=new Date();
      this.memo="";
      
      
   }
   
   public Transaction(double amount,String memo,Account whichAccount){
       //call the two arguament constructor
       this(amount,whichAccount);
       this.memo=memo;
   }
   
   public double getAmount(){
       return this.amount;
   }
   //gets a string summarizing the transaction
   public String getSummaryLine(){
       if(this.amount>=0){
           return String.format("%s : $%.02f : %s",this.timeStamp.toString(),this.amount,this.memo);
       } else{
            return String.format("%s : $(%.02f) : %s",this.timeStamp.toString(),this.amount,this.memo);
       }
   }
}
